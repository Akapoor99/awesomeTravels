// This is where the java script code for the file index.html goes !
